﻿using FestivalApplication.Data;
using Microsoft.AspNetCore.Mvc;
using FestivalApplication.Data;
using Microsoft.AspNetCore.Mvc;
using FestivalApplication.ViewModels;
using System.Linq;
using FestivalApplication.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Numerics;
using System.Runtime.CompilerServices;
using Microsoft.AspNetCore.Authorization;

namespace FestivalApplication.Controllers
{
    [Authorize]

    public class StoreController : Controller
    {
        
        public StoreController(FestivalContext context)
        {
            _context = context;
        }
        private readonly FestivalContext _context;

        //Doesn't allow anonymous
        public IActionResult addMerch(Artiest artiest, string beschrijving, string naam, int prijs)
        {
            MerchandiseListViewModel viewModel = new MerchandiseListViewModel();
            List<Product> producten = _context.Producten.ToList();
            producten.Add(new Product() { Artiest = artiest, Beschrijving = beschrijving, Naam = naam, Prijs = prijs });
            viewModel.Producten = producten.ToList();
            return View();
        }

        public IActionResult AddTicket(string beschrijving, string naam, int prijs)
        {
            MerchandiseListViewModel viewModel = new MerchandiseListViewModel();
            List<Product> producten = _context.Producten.ToList();
            producten.Add(new Product() { Beschrijving = beschrijving, Naam = naam, Prijs = prijs });
            viewModel.Producten = producten.ToList();
            return View();
        }

        //All allowAnonymous
        [AllowAnonymous]
        public IActionResult Index()
        {
            return View();
        }

        [AllowAnonymous]
        public IActionResult Tickets()
        {
            TicketListViewModel viewModel = new TicketListViewModel();
            viewModel.Producten = _context.Producten.Where(p => p.Naam.Contains("ticket")).ToList();
            return View(viewModel);
        }

        [AllowAnonymous]
        public IActionResult Merchandise()
        {
            MerchandiseListViewModel viewModel = new MerchandiseListViewModel();
            viewModel.Producten = _context.Producten.Where(p => p.Naam.Contains("trui")).ToList();
            viewModel.Producten = _context.Producten.Where(p => p.Naam.Contains("shirt")).ToList();
            return View(viewModel);
        }
    }
}
