﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FestivalApplication.Controllers
{
    [Authorize]
    public class AdminController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult AddTicket()
        {
            return View();
        }

        public IActionResult AddArtiest()
        {
            return View();
        }

        public IActionResult AddMerch()
        {
            return View();
        }
    }
}
