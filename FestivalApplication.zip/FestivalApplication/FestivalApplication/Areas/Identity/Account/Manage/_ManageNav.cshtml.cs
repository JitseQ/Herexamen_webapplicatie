using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FestivalApplication.Areas.Identity.Account.Manage
{
    public class _ManageNavModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
